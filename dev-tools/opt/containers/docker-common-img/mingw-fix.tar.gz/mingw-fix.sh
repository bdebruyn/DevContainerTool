rm /etc/alternatives/x86_64-w64-mingw32-c++
rm /etc/alternatives/x86_64-w64-mingw32-cpp
rm /etc/alternatives/x86_64-w64-mingw32-g++
rm /etc/alternatives/x86_64-w64-mingw32-gcc
rm /etc/alternatives/x86_64-w64-mingw32-gcc-ar
rm /etc/alternatives/x86_64-w64-mingw32-gcc-nm 
rm /etc/alternatives/x86_64-w64-mingw32-gcc-ranlib
rm /etc/alternatives/x86_64-w64-mingw32-gcov
rm /etc/alternatives/x86_64-w64-mingw32-gfortran
rm /etc/alternatives/x86_64-w64-mingw32-gnat
rm /etc/alternatives/x86_64-w64-mingw32-gnatbind
rm /etc/alternatives/x86_64-w64-mingw32-gnatchop
rm /etc/alternatives/x86_64-w64-mingw32-gnatclean
rm /etc/alternatives/x86_64-w64-mingw32-gnatfind
rm /etc/alternatives/x86_64-w64-mingw32-gnatkr 
rm /etc/alternatives/x86_64-w64-mingw32-gnatlink 
rm /etc/alternatives/x86_64-w64-mingw32-gnatls 
rm /etc/alternatives/x86_64-w64-mingw32-gnatmake 
rm /etc/alternatives/x86_64-w64-mingw32-gnatname 
rm /etc/alternatives/x86_64-w64-mingw32-gnatprep 
rm /etc/alternatives/x86_64-w64-mingw32-gnatxref 

ln -s /usr/bin/x86_64-w64-mingw32-c++-posix         /etc/alternatives/x86_64-w64-mingw32-c++           
ln -s /usr/bin/x86_64-w64-mingw32-cpp-posix         /etc/alternatives/x86_64-w64-mingw32-cpp           
ln -s /usr/bin/x86_64-w64-mingw32-g++-posix         /etc/alternatives/x86_64-w64-mingw32-g++           
ln -s /usr/bin/x86_64-w64-mingw32-gcc-posix         /etc/alternatives/x86_64-w64-mingw32-gcc           
ln -s /usr/bin/x86_64-w64-mingw32-gcc-ar-posix      /etc/alternatives/x86_64-w64-mingw32-gcc-ar       
ln -s /usr/bin/x86_64-w64-mingw32-gcc-nm-posix      /etc/alternatives/x86_64-w64-mingw32-gcc-nm       
ln -s /usr/bin/x86_64-w64-mingw32-gcc-ranlib-posix  /etc/alternatives/x86_64-w64-mingw32-gcc-ranlib   
ln -s /usr/bin/x86_64-w64-mingw32-gcov-posix        /etc/alternatives/x86_64-w64-mingw32-gcov         
ln -s /usr/bin/x86_64-w64-mingw32-gfortran-posix    /etc/alternatives/x86_64-w64-mingw32-gfortran     
ln -s /usr/bin/x86_64-w64-mingw32-gnat-posix        /etc/alternatives/x86_64-w64-mingw32-gnat          
ln -s /usr/bin/x86_64-w64-mingw32-gnatbind-posix    /etc/alternatives/x86_64-w64-mingw32-gnatbind     
ln -s /usr/bin/x86_64-w64-mingw32-gnatchop-posix    /etc/alternatives/x86_64-w64-mingw32-gnatchop     
ln -s /usr/bin/x86_64-w64-mingw32-gnatclean-posix   /etc/alternatives/x86_64-w64-mingw32-gnatclean    
ln -s /usr/bin/x86_64-w64-mingw32-gnatfind-posix    /etc/alternatives/x86_64-w64-mingw32-gnatfind     
ln -s /usr/bin/x86_64-w64-mingw32-gnatkr-posix      /etc/alternatives/x86_64-w64-mingw32-gnatkr       
ln -s /usr/bin/x86_64-w64-mingw32-gnatlink-posix    /etc/alternatives/x86_64-w64-mingw32-gnatlink     
ln -s /usr/bin/x86_64-w64-mingw32-gnatls-posix      /etc/alternatives/x86_64-w64-mingw32-gnatls       
ln -s /usr/bin/x86_64-w64-mingw32-gnatmake-posix    /etc/alternatives/x86_64-w64-mingw32-gnatmake     
ln -s /usr/bin/x86_64-w64-mingw32-gnatname-posix    /etc/alternatives/x86_64-w64-mingw32-gnatname     
ln -s /usr/bin/x86_64-w64-mingw32-gnatprep-posix    /etc/alternatives/x86_64-w64-mingw32-gnatprep     
ln -s /usr/bin/x86_64-w64-mingw32-gnatxref-posix    /etc/alternatives/x86_64-w64-mingw32-gnatxref     
